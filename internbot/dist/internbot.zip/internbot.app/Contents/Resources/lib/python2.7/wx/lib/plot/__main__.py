# -*- coding: utf-8 -*-

if __name__ == '__main__':
    from .examples import demo
    demo.run_demo()
